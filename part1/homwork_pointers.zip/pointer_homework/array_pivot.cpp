#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include "gtest/gtest.h"
using vecI = std::vector<int>;


using namespace std;

int pivotIndex(vecI & nums)
{
    //Your code here
    //
    return 0;
}

TEST(pivotIndex, simpleCase1)
{
    vecI nums{1,7,3,6,5,6};

    EXPECT_EQ(pivotIndex(nums), 3);
}

TEST(pivotIndex, simpleCase2)
{
    vecI nums{1,2,3};

    EXPECT_EQ(pivotIndex(nums), -1);
}


TEST(pivotIndex, simpleCase3)
{
    vecI nums{2,1,-1};

    EXPECT_EQ(pivotIndex(nums), 0);
}


TEST(pivotIndex, simpleCase4)
{
    vecI nums{-1,-1,0,1,1,0};

    EXPECT_EQ(pivotIndex(nums), 5);
}
int main(int argc, char *argv[])
{
    
   ::testing::InitGoogleTest(&argc, argv);
   return RUN_ALL_TESTS();
}
