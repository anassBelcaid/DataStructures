#include <iostream>
#include <string>
#include <vector>
#include "gtest/gtest.h"

using vecI  = std::vector<int>;
using Matrix = std::vector<vecI>;


using namespace std;



void check_array_equality(vecI & arr, vecI & arr2)
{
    EXPECT_EQ(arr.size(), arr2.size());
    for(int i = 0; i<arr.size(); i++)
        ASSERT_EQ(arr[i], arr2[i]);
}

void check_matrix_eq(Matrix & M1, Matrix & M2)
{
    
    EXPECT_EQ(M1.size(), M2.size());
    for(int i = 0; i<M1.size(); i++)
        check_array_equality(M1[i], M2[i]);

}



Matrix generate( int numRows)
{
    Matrix M;

    //Your code here

    return M;
}

TEST(pascal, simple1)
{
    Matrix M1{{1},{1,1},{1,2,1}};
    auto M2 = generate(3);

    check_matrix_eq(M1,  M2);
}

TEST(pascal, simple2)
{
    Matrix M1{{1}};
    auto M2 = generate(1);

    check_matrix_eq(M1,  M2);
}

TEST(pascal, simple3)
{
    Matrix M1{{1},{1,1},{1,2,1},{1,3,3,1},{1,4,6,4,1}};
    auto M2 = generate(5);

    check_matrix_eq(M1,  M2);
}


int main(int argc, char *argv[])
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
