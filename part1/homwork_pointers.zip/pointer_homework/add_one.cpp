#include <iostream>
#include <string>
#include <vector>
#include "gtest/gtest.h"
using vecI = std::vector<int>;

using namespace std;


//add one function
vecI  addOne(vecI & nums)
{
    /** Assume nums contains the digits of a number
     * Return an array that represent number + 1
     * You can assume that begin and end has the same arithmetique as pointers
     */

    //Your code here good luck passing the last test!!
}

void check_array_equality(vecI & arr, vecI & arr2)
{
    for(int i = 0; i<arr.size(); i++)
        ASSERT_EQ(arr[i], arr2[i]);
}

TEST(addOne, simpleCase1)
{

    vecI arr{1,2,3};
    auto comp = addOne(arr);
    vecI out{1,2,4};


    check_array_equality(comp, out);

}

TEST(addOne, simpleCase2)
{

    vecI arr{4,3,2,1};
    vecI comp = addOne(arr);
    vecI out{4,3,2,2};

    check_array_equality(comp, out);

}

TEST(addOne, simpleCase3)
{
    vecI arr{0};
    auto comp = addOne(arr);
    vecI out{1};

    check_array_equality(comp, out);

}

TEST(addOne, sizeChange1)
{

    vecI arr{9};
    auto com = addOne(arr);
    vecI out{1,0};

    check_array_equality(com, out);

}

TEST(addOne,  crazy)
{
    vecI arr{7,2,8,5,0,9,1,2,9,5,3,6,6,7,3,2,8,4,3,7,9,5,7,7,4,7,4,9,4,7,0,1,1,1,7,4,0,0,6};
    auto comp = addOne(arr);
    vecI out{7,2,8,5,0,9,1,2,9,5,3,6,6,7,3,2,8,4,3,7,9,5,7,7,4,7,4,9,4,7,0,1,1,1,7,4,0,0,7};

    check_array_equality(comp, out);
}

int main(int argc, char *argv[])
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
