#include <iostream>
#include <string>
#include <vector>
#include "gtest/gtest.h"
using vecI = std::vector<int>;

using namespace std;

void check_array_equality(vecI & arr, vecI & arr2)
{
    for(int i = 0; i<arr.size(); i++)
        ASSERT_EQ(arr[i], arr2[i]);
}


vecI spiralOrder(vector<vector<int>> & M)
{
    vecI A ;

    //Your code here

    return A;
}

TEST(spiral, test1)
{
 vector<vector<int>> M{{1,2,3},{4,5,6},{7,8,9}};
 auto out = spiralOrder(M);
 vecI exp{1,2,3,6,9,8,7,4,5};

 check_array_equality(exp, out);
}

TEST(spiral, test2)
{
 vector<vector<int>> M{{1,2,3,4},{5,6,7,8},{9,10,11,12}};
 auto out = spiralOrder(M);
 vecI exp{1,2,3,4,8,12,11,10,9,5,6,7};

 check_array_equality(exp, out);
}
int main(int argc, char *argv[])
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
