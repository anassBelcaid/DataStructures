#include <iostream>
#include <string>
#include <vector>
#include "gtest/gtest.h"
using vecI = std::vector<int> ;

using namespace std;

int dominantIndex( vector<int> & nums)
{

    //Your code here

}


TEST(dominant, test1)
{
 vecI arr{3, 6, 1, 0};

 EXPECT_EQ(dominantIndex(arr),  1);
}

TEST(dominant, singleValue)
{
 vecI arr{3};

 EXPECT_EQ(dominantIndex(arr),  0);
}

TEST(dominant, none)
{
    
 vecI arr{3, 4, 5, 2, 4, 2, 1};

 EXPECT_EQ(dominantIndex(arr),  -1);
}

TEST(dominant, same)
{
    
 vecI arr{1,2,3,3};

 EXPECT_EQ(dominantIndex(arr),  -1);
}

int main(int argc, char *argv[])
{
      ::testing::InitGoogleTest(&argc, argv);
      return RUN_ALL_TESTS();
}
