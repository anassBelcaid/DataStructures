/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
#include <sstream>
#include "linkedlist.h"
using namespace std;


// Preferably implment first
ostream & operator<<(ostream & out,  LinkedList  L)
{
    // Overload the ostream operator to print the list
    // list should be printed as
    // e1 -> e2 -> e3 .... en
    // be carefull about the spacing

    return out;
}

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;

    return 0;
}



PROVIDED_TEST("Singly Linked List Constructor")
{
  auto H = LinkedList();

  assert(H.getHead() == nullptr);

}

PROVIDED_TEST("Ostream Operator 1")
{
   auto H = LinkedList();
   stringstream ss;
   cout << H  << endl;

   EXPECT_EQUAL( ss.str(), "");

}

PROVIDED_TEST("Add at Head 1")
{
   auto H = LinkedList();
   H.addAtHead(1);

   stringstream ss;
   ss << H;
   EXPECT_EQUAL(ss.str(), "1");
}

PROVIDED_TEST("Add at Head 2")
{
   auto H = LinkedList();
   H.addAtHead(1);
   H.addAtHead(2);
   H.addAtHead(3);

   stringstream ss;
   ss << H;
   EXPECT_EQUAL(ss.str(), "3 -> 2 -> 1");
}


PROVIDED_TEST("Add at Tail 1")
{
   auto H = LinkedList();
   H.addAtHead(1);
   H.addAtTail(2);
   H.addAtTail(3);

   stringstream ss;
   ss << H;
   EXPECT_EQUAL(ss.str(), "1 -> 2 -> 3");
}



PROVIDED_TEST("Add at Tail on empty list")
{
   auto H = LinkedList();

   H.addAtTail(1);
   H.addAtTail(2);

   stringstream ss;
   ss << H;
   EXPECT_EQUAL(ss.str(), "1 -> 2");
}


PROVIDED_TEST("Add at Tail Combined")
{
   auto H = LinkedList();

   H.addAtTail(1);
   H.addAtHead(4);
   H.addAtTail(2);

   stringstream ss;
   ss << H;
   EXPECT_EQUAL(ss.str(), "4 -> 1 -> 2");
}

PROVIDED_TEST("Size of the linked list")
{
   auto H = LinkedList();

   EXPECT_EQUAL( H.size(), 0);
   H.addAtTail(1);
   EXPECT_EQUAL( H.size(), 1);
   H.addAtHead(4);
   EXPECT_EQUAL( H.size(), 2);
   H.addAtTail(2);
   EXPECT_EQUAL( H.size(), 3);
}



PROVIDED_TEST("Inserting simple tests")
{
    auto H = LinkedList();

    //adding some values
    H.addAtHead(3);
    H.addAtHead(2);
    H.addAtHead(1);

    //addign betwwen 1 and 2
    H.addAtIndex(4, 1);
    stringstream ss;
    ss << H;
    EXPECT_EQUAL(ss.str(), "1 -> 4 -> 2 -> 3");

   //adding a value between 4 and 2
    H.addAtIndex(5, 2);
    ss.str("");
    ss << H;
    EXPECT_EQUAL(ss.str(), "1 -> 4 -> 5 -> 2 -> 3");
}

PROVIDED_TEST("Inserting extreme tests")
{
   auto H = LinkedList();
   H.addAtIndex(1, 0);
   stringstream ss;
   ss << H ;
   EXPECT_EQUAL(ss.str(), "1");

   H.addAtIndex(2, -1);     //inserting at position -1 should do nothing
   ss.str("");
   ss << H ;
   EXPECT_EQUAL(ss.str(), "1");
   EXPECT_EQUAL(H.size(), 1);

   H.addAtIndex(2, 2);     //inserting at position 2 should do nothing
   ss.str("");
   ss << H ;
   EXPECT_EQUAL(ss.str(), "1");
   EXPECT_EQUAL(H.size(), 1);

   H.addAtIndex(2, 1);     //inserting at the end
   ss.str("");
   ss << H ;
   EXPECT_EQUAL(ss.str(), "1 -> 2");
   EXPECT_EQUAL(H.size(), 2);

}


PROVIDED_TEST("Deleting")
{
   //deleting an empty list
   auto H = LinkedList();
   H.deleteAtIndex(0);
   H.deleteAtIndex(1);

   stringstream ss;
   cout << H;
   EXPECT_EQUAL(ss.str(), "");


   //filling the list with some values
   H.addAtHead(4);
   H.addAtHead(3);
   H.addAtHead(2);
   H.addAtHead(1);

   //deleting at first value
   H.deleteAtIndex(0);
   ss.str("");
   ss << H;
   EXPECT_EQUAL(ss.str(), "2 -> 3 -> 4");
   H.addAtHead(1);


   //deleting at last
   H.deleteAtIndex(3);
   ss.str("");
   ss << H;
   EXPECT_EQUAL(ss.str(), "1 -> 2 -> 3");
   H.addAtTail(4);



   //deleting at middle
   H.deleteAtIndex(2);
   ss.str("");
   ss << H;
   EXPECT_EQUAL(ss.str(), "1 -> 2 -> 4");
}
