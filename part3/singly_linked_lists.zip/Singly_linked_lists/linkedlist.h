#ifndef LINKEDLIST_H
#define LINKEDLIST_H

// Definition for singly-linked list.
struct SinglyListNode {
    int val;
    SinglyListNode *next;
    //Constructor
    SinglyListNode(int x) : val(x), next(nullptr) {}
};


class LinkedList
{
public:
    LinkedList(); // default constructor

    //getters
    int get(int index);

    SinglyListNode * getHead()const;

    //setters
    void addAtHead(int value);
    void addAtTail(int value);
    void addAtIndex(int value,  int index);
    void deleteAtIndex(int index);

    //methods
    int size()const;
private:
    SinglyListNode * head;

};




#endif // LINKEDLIST_H
