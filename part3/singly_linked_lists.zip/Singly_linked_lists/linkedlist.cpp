#include "linkedlist.h"
#include "ostream"
using std::ostream;

// implement the default constructor here
LinkedList::LinkedList()
{
    // your code here
  head = nullptr;
}

// do not modify
SinglyListNode * LinkedList::getHead() const
{
    return head;
}


//add at Head

void LinkedList::addAtHead(int value)
{
    // Put your code here where you add value as the first value
}



// Add at tail
void LinkedList::addAtTail(int value)
{
    //put your code here to add node in the tail of the linked list

}


// Size method
int LinkedList::size() const
{
    //put your code here in order to compute the size
    return 0;
}

// add At Index
void LinkedList::addAtIndex(int value, int index)
{
    //Put your code here
    // index should be between [0, and lenght]
    // if index equals lenght append at tail


}


void LinkedList::deleteAtIndex(int index)
{
    // put your code here
    // this function should delete the node at index
    // if index < 0 or index >= size dot nothing

}


