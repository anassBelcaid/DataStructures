/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;


// Definition for singly-linked list.
struct SinglyListNode {
    int val;
    SinglyListNode *next;
    //Constructor
    SinglyListNode(int x) : val(x), next(NULL) {}
};


/*
 * Detect cycles
 */
bool has_cycle( SinglyListNode * head)
{
    // Function to verify if the linked list
    // starting from head has a cycle

    // Use the two pointer technique to detect the cycles

    return false;
}

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("First Exemple ")
{
    SinglyListNode *n1 = new SinglyListNode(3);
    SinglyListNode *n2 = new SinglyListNode(2);
    SinglyListNode *n3 = new SinglyListNode(0);
    SinglyListNode *n4 = new SinglyListNode(-4);

    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = n2;

    EXPECT_EQUAL(has_cycle(n1), true);
}


PROVIDED_TEST("second Example")
{

    SinglyListNode *n1 = new SinglyListNode(3);
    SinglyListNode *n2 = new SinglyListNode(2);

    n1->next = n2;
    n2->next = n1;

    EXPECT_EQUAL(has_cycle(n1), true);
}


PROVIDED_TEST("Third exemple")
{

    SinglyListNode *n1 = new SinglyListNode(3);


    EXPECT_EQUAL(has_cycle(n1), false);
}

PROVIDED_TEST("linear 50")
{
   auto head = new SinglyListNode(0);
   auto C = head;

   for(int i=0;  i< 49; i++)
   {
       auto curr = new SinglyListNode(i);
       C->next = curr;
       C = curr;
   }

   EXPECT_EQUAL(has_cycle(head), false);

}

PROVIDED_TEST("Cycle 50")
{
   auto head = new SinglyListNode(0);
   auto C = head;
   SinglyListNode * curr;

   for(int i=0;  i< 49; i++)
   {
       curr = new SinglyListNode(i);
       C->next = curr;
       C = curr;
   }

   //creating a cycle
   curr->next = head;


   EXPECT_EQUAL(has_cycle(head), true);

}


PROVIDED_TEST("Cycle 501")
{
   auto head = new SinglyListNode(0);
   auto C = head;
   SinglyListNode * curr;

   for(int i=0;  i< 49; i++)
   {
       curr = new SinglyListNode(i);
       C->next = curr;
       C = curr;
   }

   //creating a cycle
   curr->next = head->next->next;


   EXPECT_EQUAL(has_cycle(head), true);

}
