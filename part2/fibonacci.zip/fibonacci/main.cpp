/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
#include "hashmap.h"
using namespace std;

/* REcursive implementatin of the fibonnaci function
 */
using Dict = HashMap<int, long>;

long fib(int n)
{
    // Put your code here

    return 0;
}


/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}


/* Test cases
fib(0) = 0
fib(1) = 1
fib(5) = 5
fib(10) = 55
fib(100) % (10^8 +7) = 24278230
*/

PROVIDED_TEST("Base Case 0")
{
    EXPECT_EQUAL(fib(0), 0);
}

PROVIDED_TEST("Base Case 1")
{
    EXPECT_EQUAL(fib(1), 1);
}

PROVIDED_TEST("Simple Case 5")
{
    EXPECT_EQUAL(fib(5), 5);
}

PROVIDED_TEST("Simple Case 10")
{
    EXPECT_EQUAL(fib(10), 55);
}


PROVIDED_TEST("Simple Case 55")
{
    EXPECT_EQUAL( fib(55), 139583862445);
}
