/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */
#include <iostream>
#include "console.h"
#include "gwindow.h"
#include "gobjects.h"

using namespace std;


void carpet(GWindow &win, int x, int y, int width, int order)
{

    //Draw the Sierpensky carpet of order [order]
    //Put your code here


}
/*
 * This sample main brings up testing menu.
 */
int main() {

    // Width of the window
    int width = 600;

    //order of the carpet
    int order = 5;
    GWindow app(width, width);


    //Drawing the carpet
    carpet(app, 0, 0, width, order);

    return 1;
}
