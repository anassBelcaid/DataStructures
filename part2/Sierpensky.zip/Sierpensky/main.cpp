/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "gwindow.h"
#include "gobjects.h"
#include  <math.h>
using namespace std;

/* Function to draw A Sierpensky triangle */

void draw_triangle(GWindow & win, float x, float y, float width)
{
    /* Draw a isosele triangle of width  [width] on the window [win] in the position [x,y]
     */

    //Creating the Polygon
    GPolygon * poly = new GPolygon();

    //adding the point
    poly->addVertex(x, y);


    //adding the other two points
    for(int i = 0; i < 2 ; i++)
        poly->addPolarEdge(width, i * 120);


    poly->setFilled(true);

    win.add(poly);

}


/* The main function that you should implement
 */


void Sierpensky(GWindow & win, float x, float y, float width,  int order=1)
{
    /*Draw the Sierpensky triangle of order [order]
     */
}

/*
 * This sample main brings up testing menu.
 */
int main() {


    //Create a window to draw the triangles
    GWindow gw(600, 600);




    
    int order;
    cout << "Enter the order of your triangle: ";
    cin  >> order;

    Sierpensky(gw, 0, gw.getHeight(), gw.getWidth(), order);


    return 0;
}
