/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;


int fact(int n)
{
    //Recursive function to imiplement the factorial

    return 0;
}

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("TEST 1 Basic Case")
{
    EXPECT_EQUAL(1, fact(1));
}
PROVIDED_TEST("TEST 2 Basic Case")
{
    EXPECT_EQUAL(2, fact(2));
}

PROVIDED_TEST("TEST 3 Basic Case")
{
    EXPECT_EQUAL(6, fact(3));
}

PROVIDED_TEST("TEST 4 Basic Case")
{
    EXPECT_EQUAL(24, fact(4));
}
PROVIDED_TEST("TEST 2 Basic Case")
{
    EXPECT_EQUAL(120, fact(5));
}


