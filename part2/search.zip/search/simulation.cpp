#include <iostream>
#include <chrono>
#include "tests.h"

using namespace std;


float timing(int(*F)(vecI & , int), vecI & nums, int target)
{
    //Votre code ici pour calculer l'erreur
}

int main(int argc, char *argv[])
{
  // Assurer que votre fonction est correcte.
  tests(&linear_search);


 // Tester le temps d'exécution.

  
    
  return 0;
}
