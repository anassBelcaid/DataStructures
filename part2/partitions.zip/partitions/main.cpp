/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;


int number_partitions(int number, int limit, int upto=1)
{
    // your code here

 }

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
   cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("Sample use of (6,4)")
{
    auto value = number_partitions( 6, 4);
    EXPECT_EQUAL(value, 9);
}

PROVIDED_TEST("Sample use of SimpleTest")
{
    auto value = number_partitions( 5, 5);
    EXPECT_EQUAL(value, 7);
}

PROVIDED_TEST("Test 3 (5, 5) ")
{
    auto value = number_partitions( 5, 5);
    EXPECT_EQUAL(value, 7);
}

PROVIDED_TEST("Test 4 (15, 15) ")
{
    auto value = number_partitions( 15, 15);
    EXPECT_EQUAL(value, 176);
}

PROVIDED_TEST("Test 5 (20 , 20)")
{
    auto value = number_partitions( 20, 20);
    EXPECT_EQUAL(value,  627);
}
