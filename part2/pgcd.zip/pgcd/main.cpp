/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;


/* Recursive implementation of the gcd function
 */

int gcd(int a, int b)
{
    // Put your recursive implementation here
    return 0;

}
/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

/*
 * Unit Tests
 * ----------
 * 1. gcd(42, 56) = 14
 * 2. gcd(461952, 116298) = 18
 * 3. gcd(7966496, 314080416) = 32
 * 4. gcd(24826148, 45296490) = 526
 * 5. gcd(12, 0) = 12
 * 6. gcd(0, 0) = 0
 * 7. gcd(0, 9) = 9
 */

PROVIDED_TEST("TEST1")
{
    EXPECT_EQUAL(14, gcd(42, 56));
}

PROVIDED_TEST("TEST2")
{
    EXPECT_EQUAL(gcd(461952, 116298) , 18);
}


PROVIDED_TEST("TEST3")
{
    EXPECT_EQUAL(gcd(7966496, 314080416) , 32);
}

PROVIDED_TEST("TEST4")
{
    EXPECT_EQUAL( gcd(24826148, 45296490) , 526);

}

PROVIDED_TEST("TEST5")
{
    EXPECT_EQUAL(gcd(12, 0) , 12);
}

PROVIDED_TEST("TEST6")
{
    EXPECT_EQUAL(gcd(0, 0) , 0);
}

PROVIDED_TEST("TEST7")
{
    EXPECT_EQUAL(gcd(0, 9) , 9);
}
